# CrystalDrop.gg

- `index.html` is the whole website (one file). GitHub Pages or Cloudflare Pages can serve it as is.
- `deposit-server/` is the Node 22 server for accounts and crypto deposits. See `deposit-server/README.md`. Never upload your `.env` file.
